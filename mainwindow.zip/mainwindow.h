#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QList>
#include <QDebug>
#include <QMap>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT
signals:
    void display(QString number);
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    int stockMaxIndex,cutMaxIndex;
    long int scrap=0,minScrap=99999;
    QList<int> minChromosome;
    QList<int> stockItems;
    QList<int> cutItems;
    QList<int> chromosome;
    QList<int> tempStockItems,tempCutItems;
    QList<QList<int>> chromosomes;
    QList<int> fitness;
    QList<int> scraps;

    void reset();
    void getTextData();
    int minfit(QList<int> t,int cutting=0);
    int maxfit(QList<int> t,int cutting=0);
    int max(QList<int> t);
    int min(QList<int> t);
    void generation();
    void fitnessCalc();
    void selection();
    void crossover();
    void mutation();
private slots:
    void on_optimizeButton_clicked();

//    void on_showPopulation_clicked();

//    void on_selection_clicked();

    void on_showResult_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
